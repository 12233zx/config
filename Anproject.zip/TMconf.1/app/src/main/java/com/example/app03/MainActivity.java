package com.example.app03;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText permittivity;
    private EditText conductivity;
    private EditText frequency;
    private Button exit;
    private Button clear;
    private Button calculate;
    private Button ok;
    private EditText nacl;
    private EditText oil;
    private Spinner spinner;
    String spinnercontext;
    int posOpera = 100;
     public class MatrixCalculate {
         //矩阵加法 C=A+B
         public double[][] MatrixAdd(double[][] m1, double[][] m2) {
             if (m1 == null || m2 == null ||
                     m1.length != m2.length ||
                     m1[0].length != m2[0].length) {
                 return null;
             }
             double[][] m = new double[m1.length][m1[0].length];
             for (int i = 0; i < m.length; ++i) {
                 for (int j = 0; j < m[i].length; ++j) {
                     m[i][j] = m1[i][j] + m2[i][j];
                 }
             }
             return m;
         }

         //矩阵转置
         public double[][] MatrixTranspose(double[][] m) {
             double[][] b = new double[m[0].length][m.length];
             for (int i = 0; i < m[0].length; i++) {
                 for (int j = 0; j < m.length; j++) {
                     b[i][j] = m[j][i];
                 }
             }
             return b;
         }

         //矩阵相乘 C=A*B
         public double[][] MatrixMultiply(double[][] a, double[][] b) {

             if (a[0].length != b.length) {

                 return null;

             }
             double[][] c = new double[a.length][b[0].length];

             for (int i = 0; i < a.length; i++) {

                 for (int j = 0; j < b[0].length; j++) {

                     for (int k = 0; k < a[0].length; k++) {

                         c[i][j] += a[i][k] * b[k][j];
                     }
                 }
             }
             return c;
         }
     }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        permittivity=findViewById(R.id.permitive);
        conductivity=findViewById(R.id.conductive);
        frequency=findViewById(R.id.frequency);
        exit=findViewById(R.id.exit);
        clear=findViewById(R.id.clear);
        calculate=findViewById(R.id.calculate);
        ok=findViewById(R.id.ok);
        nacl=findViewById(R.id.nacl);
        oil=findViewById(R.id.oil);
        spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                spinnercontext = MainActivity.this.getResources().getStringArray(R.array.option)[position];
                posOpera =position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this,"no select",Toast.LENGTH_SHORT).show();
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               finish();
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                permittivity.setText("");
                conductivity.setText("");
                frequency.setText("");
                nacl.setText("");
                oil.setText("");
            }
        });
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str1 = permittivity.getText().toString();
                String str2 = conductivity.getText().toString();
                String str4 = frequency.getText().toString();
                double per =  Double.parseDouble(str1);
                double con =  Double.parseDouble(str2);
                double fre =  Double.parseDouble(str4);
                data z=new data();
                data2 z2=new data2();
                MatrixCalculate matrixCalculate = new MatrixCalculate();
                double a__w1[][] = matrixCalculate.MatrixTranspose(z.a_w1);
                double a__b1[][] = matrixCalculate.MatrixTranspose(z.a_b1);
                double a__w2[][] = matrixCalculate.MatrixTranspose(z.a_w2);
                double a__b2[][] = matrixCalculate.MatrixTranspose(z.a_b2);
                double a__w3[][] = matrixCalculate.MatrixTranspose(z.a_w3);
                double a__w4[][] = matrixCalculate.MatrixTranspose(z.a_w4);
                double a__b3[][] = matrixCalculate.MatrixTranspose(z.a_b3);
                double a__b4[][] = matrixCalculate.MatrixTranspose(z.a_b4);
                double fre1 =  6.70241286863271* (fre- 16)*0.0001-1;//归一化
                double permi1 = ((1 - (-1)) / (190.81 - 5.3584)) * (per - 5.3584) + (-1);//归一化
                double condu1 = ((1 - (-1)) / (3.4897 - (-0.00010714))) * (con - (-0.00010714)) + (-1);//归一化
                double inputData[][] = {{permi1}, {condu1}, {fre1}};

                double hidden1[][] = logsig(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w1, inputData), a__b1));//100*1
                double hidden2[][] = poslin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w2, hidden1), a__b2));//50*1
                double hidden3[][] = purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w3, hidden2), a__b3));//30*1
                double aaaaa[][]=matrixCalculate.MatrixMultiply(a__w3, hidden2);
                double[][] out1 = purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w4, hidden3), a__b4));//1
                double Output1 = ((1.4 - 0) / (1 - (-1))) * (out1[0][0] - (-1)) + 0;//反归一化
                //转换成String
                double[][] out2;
                double b__w1[][] = matrixCalculate.MatrixTranspose(z2.b_w1);
                double b__b1[][] = matrixCalculate.MatrixTranspose(z2.b_b1);
                double b__w2[][] = matrixCalculate.MatrixTranspose(z2.b_w2);
                double b__b2[][] = matrixCalculate.MatrixTranspose(z2.b_b2);
                double b__w3[][] = matrixCalculate.MatrixTranspose(z2.b_w3);
                double b__w4[][]= matrixCalculate.MatrixTranspose(z2.b_w4);
                double b__b3[][] = matrixCalculate.MatrixTranspose(z2.b_b3);
                double b__b4[][]= matrixCalculate.MatrixTranspose(z2.b_b4);

                double hidden1_1[][] = logsig(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w1, inputData), b__b1));//100*1
                double hidden2_1[][]= poslin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w2, hidden1_1), b__b2));//50*1
                double hidden3_1[][]= purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w3, hidden2_1), b__b3));//50*1
                out2 = purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w4, hidden3_1), b__b4));//1
                double Output2 = (0.8 - 0) / (1 - (-1)) * (out2[0][0] - (-1)) + 0;//反归一化
                if (Output2 < 0) {
                    Output2 = 0;
                }
                nacl.setText( Output1+ "");
                oil.setText(  Output2+ "");
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
               int posit=posOpera+1;     //组织位置
               String str4 = frequency.getText().toString();
               double fre = Double.parseDouble(str4) * 10e5;
               data z=new data();
               double[] tissue_arr = z.arrA[posOpera];
               double tissue_sgm = tissue_arr[0];
               double tissue_eps_inf = tissue_arr[1];
               double tissue_eps_s1 = tissue_arr[2];
               double tissue_tao1 = tissue_arr[3]*1e-6;
               double tissue_alf1 = tissue_arr[4];
               double tissue_eps_s2 = tissue_arr[5];
               double tissue_tao2 = tissue_arr[6]*1e-6;
               double tissue_alf2 = tissue_arr[7];
               double tissue_eps_s3 = tissue_arr[8];
               double tissue_tao3 = tissue_arr[9]*1e-6;
               double tissue_alf3 = tissue_arr[10];
               double tissue_eps_s4 = tissue_arr[11];
               double tissue_tao4 = tissue_arr[12];
               double tissue_alf4 = tissue_arr[13];
               double tissue_w = 2 * fre * Math.PI;
                double eps_0 = 8.854187817e-12;
                MatrixCalculate matrixCalculate = new MatrixCalculate();
                double tissue_real = tissue_eps_inf +
                        (tissue_eps_s1 - tissue_eps_inf) * (1 + Math.pow(tissue_w * tissue_tao1, 1 - tissue_alf1) * Math.sin(tissue_alf1 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf1 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao1), (1 - tissue_alf1)) + (Math.pow(tissue_w * tissue_tao1, 2 * (1 - tissue_alf1)))) +
                        (tissue_eps_s2 - tissue_eps_inf) * (1 + Math.pow(tissue_w * tissue_tao2, 1 - tissue_alf2) * Math.sin(tissue_alf2 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf2 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao2), (1 - tissue_alf2)) + (Math.pow(tissue_w * tissue_tao2, 2 * (1 - tissue_alf2)))) +
                        (tissue_eps_s3 - tissue_eps_inf) * (1 + Math.pow(tissue_w * tissue_tao3, 1 - tissue_alf3) * Math.sin(tissue_alf3 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf3 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao3), (1 - tissue_alf3)) + (Math.pow(tissue_w * tissue_tao3, 2 * (1 - tissue_alf3)))) +
                        (tissue_eps_s4 - tissue_eps_inf) * (1 + Math.pow(tissue_w * tissue_tao4, 1 - tissue_alf4) * Math.sin(tissue_alf4 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf4 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao4), (1 - tissue_alf4)) + (Math.pow(tissue_w * tissue_tao4, 2 * (1 - tissue_alf4))));
                double tissue_imag = tissue_sgm / (tissue_w * eps_0) +
                        ((tissue_eps_s1 - tissue_eps_inf) * Math.pow(tissue_w * tissue_tao1, 1 - tissue_alf1) * Math.cos(tissue_alf1 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf1 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao1), (1 - tissue_alf1)) + (Math.pow(tissue_w * tissue_tao1, 2 * (1 - tissue_alf1)))) +
                        ((tissue_eps_s2 - tissue_eps_inf) * Math.pow(tissue_w * tissue_tao2, 1 - tissue_alf2) * Math.cos(tissue_alf2 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf2 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao2), (1 - tissue_alf2)) + (Math.pow(tissue_w * tissue_tao2, 2 * (1 - tissue_alf2)))) +
                        ((tissue_eps_s3 - tissue_eps_inf) * Math.pow(tissue_w * tissue_tao3, 1 - tissue_alf3) * Math.cos(tissue_alf3 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf3 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao3), (1 - tissue_alf3)) + (Math.pow(tissue_w * tissue_tao3, 2 * (1 - tissue_alf3)))) +
                        ((tissue_eps_s4 - tissue_eps_inf) * Math.pow(tissue_w * tissue_tao4, 1 - tissue_alf4) * Math.cos(tissue_alf4 * (Math.PI) / 2)) / (1 + Math.sin(tissue_alf4 * (Math.PI) / 2) * 2 * Math.pow((tissue_w * tissue_tao4), (1 - tissue_alf4)) + (Math.pow(tissue_w * tissue_tao4, 2 * (1 - tissue_alf4))));
                double tissue_SGM = tissue_w * eps_0 * tissue_imag;
                double tissue_EPS = tissue_real;
                permittivity.setText(tissue_EPS + "");
                conductivity.setText(tissue_SGM + "");
                /*c.setText("");*/
                double per=tissue_EPS;
                double con=tissue_SGM;
                data z33=new data();
                data2 z44=new data2();
                double a__w1[][] = matrixCalculate.MatrixTranspose(z33.a_w1);
                double a__b1[][] = matrixCalculate.MatrixTranspose(z33.a_b1);
                double a__w2[][] = matrixCalculate.MatrixTranspose(z33.a_w2);
                double a__b2[][] = matrixCalculate.MatrixTranspose(z33.a_b2);
                double a__w3[][] = matrixCalculate.MatrixTranspose(z33.a_w3);
                double a__w4[][] = matrixCalculate.MatrixTranspose(z33.a_w4);
                double a__b3[][] = matrixCalculate.MatrixTranspose(z33.a_b3);
                double a__b4[][] = matrixCalculate.MatrixTranspose(z33.a_b4);
                double Fff=fre/1E6;
                double fre1 =  6.70241286863271* (Fff- 16)*0.0001-1;//归一化
                double permi1 = ((1 - (-1)) / (190.81 - 5.3584)) * (per - 5.3584) + (-1);//归一化
                double condu1 = ((1 - (-1)) / (3.4897 - (-0.00010714))) * (con - (-0.00010714)) + (-1);//归一化
                double inputData[][] = {{permi1}, {condu1}, {fre1}};
                double hidden1[][] = logsig(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w1, inputData), a__b1));//100*1
                double hidden2[][] = poslin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w2, hidden1), a__b2));//50*1
                double hidden3[][] = purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w3, hidden2), a__b3));//30*1
                double[][] out1 = purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(a__w4, hidden3), a__b4));//1
                double Output1 = ((1.4 - 0) / (1 - (-1))) * (out1[0][0] - (-1)) + 0;   //反归一化
                //转换成String
                double[][] out2;
                double b__w1[][] = matrixCalculate.MatrixTranspose(z44.b_w1);
                double b__b1[][] = matrixCalculate.MatrixTranspose(z44.b_b1);
                double b__w2[][] = matrixCalculate.MatrixTranspose(z44.b_w2);
                double b__b2[][] = matrixCalculate.MatrixTranspose(z44.b_b2);
                double b__w3[][] = matrixCalculate.MatrixTranspose(z44.b_w3);
                double b__w4[][]= matrixCalculate.MatrixTranspose(z44.b_w4);
                double b__b3[][] = matrixCalculate.MatrixTranspose(z44.b_b3);
                double b__b4[][]= matrixCalculate.MatrixTranspose(z44.b_b4);

                double hidden1_1[][] = logsig(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w1, inputData), b__b1));//100*1
                double hidden2_1[][]= poslin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w2, hidden1_1), b__b2));//50*1
                double hidden3_1[][]= purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w3, hidden2_1), b__b3));//50*1
                out2 = purelin(matrixCalculate.MatrixAdd(matrixCalculate.MatrixMultiply(b__w4, hidden3_1), b__b4));//1
                double Output2 = 0.8 / 2 * (out2[0][0] +1) ;//反归一化
                if (Output2 < 0) {
                    Output2 = 0;
                }
               nacl.setText(Output1 + "");
               oil.setText(Output2+ "");
           }
       });
    }
    public double[][] logsig(double[][] s) {
        double y[][] = new double[100][1];
        for (int i = 0; i < s.length; i++) {
            for (int j = 0; j < s[i].length; j++) {
                y[i][j] = 1 / (1 + Math.pow(Math.E, -s[i][j]));
            }
        }
        return y;
    }
    public double[][] radbas(double[][] k) {
        double a[][] = new double[100][1];
        for (int i = 0; i < k.length; i++) {
            for (int j = 0; j < k[i].length; j++) {
                a[i][j] = 1 / Math.pow(Math.E, k[i][j]);
            }
        }
        return a;
    }
    public double[][] poslin(double[][] arr) {
        double c[][]=new double[50][1];
        for (int x = 0; x < arr.length; x++) {
            for (int y = 0; y < arr[x].length; y++) {
                if (arr[x][y] < 0) {
                    arr[x][y] = 0;
                }
                c[x][y]=arr[x][y];
            }
        }
        return c;
    }
    public double[][] purelin(double[][] p) {
        return p;
    }
}